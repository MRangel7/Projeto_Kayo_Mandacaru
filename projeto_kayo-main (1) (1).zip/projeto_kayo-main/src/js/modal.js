// MODAL 1

const openModalBtn = document.getElementById("openModalBtn");
const closeModalBtn = document.getElementById("closeModalBtn");
const modal = document.getElementById("myModal");

openModalBtn.addEventListener("click", () => {
    modal.style.display = "block";
});

closeModalBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal) {
        modal.style.display = "none";
    }
});

// MODAL 2

const openModalBtn2 = document.getElementById("openModalBtn2");
const closeModalBtn2 = document.getElementById("closeModalBtn2");
const modal2 = document.getElementById("myModal2");

openModalBtn2.addEventListener("click", () => {
    modal2.style.display = "block";
});

closeModalBtn2.addEventListener("click", () => {
    modal2.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal2) {
        modal2.style.display = "none";
    }
});

// MODAL 3

const openModalBtn3 = document.getElementById("openModalBtn3");
const closeModalBtn3 = document.getElementById("closeModalBtn3");
const modal3 = document.getElementById("myModal3");

openModalBtn3.addEventListener("click", () => {
    modal3.style.display = "block";
});

closeModalBtn3.addEventListener("click", () => {
    modal3.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal3) {
        modal3.style.display = "none";
    }
});



// LINHA 2



// MODAL 4

const openModalBtn4 = document.getElementById("openModalBtn4");
const closeModalBtn4 = document.getElementById("closeModalBtn4");
const modal4 = document.getElementById("myModal4");

openModalBtn4.addEventListener("click", () => {
    modal4.style.display = "block";
});

closeModalBtn4.addEventListener("click", () => {
    modal4.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal4) {
        modal4.style.display = "none";
    }
});

// MODAL 5

const openModalBtn5 = document.getElementById("openModalBtn5");
const closeModalBtn5 = document.getElementById("closeModalBtn5");
const modal5 = document.getElementById("myModal5");

openModalBtn5.addEventListener("click", () => {
    modal5.style.display = "block";
});

closeModalBtn5.addEventListener("click", () => {
    modal5.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal5) {
        modal5.style.display = "none";
    }
});

// MODAL 6

const openModalBtn6 = document.getElementById("openModalBtn6");
const closeModalBtn6 = document.getElementById("closeModalBtn6");
const modal6 = document.getElementById("myModal6");

openModalBtn6.addEventListener("click", () => {
    modal6.style.display = "block";
});

closeModalBtn6.addEventListener("click", () => {
    modal6.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal6) {
        modal6.style.display = "none";
    }
});



// NOTICIAS LINHA 3



// MODAL 7

const openModalBtn7 = document.getElementById("openModalBtn7");
const closeModalBtn7 = document.getElementById("closeModalBtn7");
const modal7 = document.getElementById("myModal7");

openModalBtn7.addEventListener("click", () => {
    modal7.style.display = "block";
});

closeModalBtn7.addEventListener("click", () => {
    modal7.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal7) {
        modal7.style.display = "none";
    }
});

// MODAL 8

const openModalBtn8 = document.getElementById("openModalBtn8");
const closeModalBtn8 = document.getElementById("closeModalBtn8");
const modal8 = document.getElementById("myModal8");

openModalBtn8.addEventListener("click", () => {
    modal8.style.display = "block";
});

closeModalBtn8.addEventListener("click", () => {
    modal8.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal8) {
        modal8.style.display = "none";
    }
});

// MODAL 8

const openModalBtn9 = document.getElementById("openModalBtn9");
const closeModalBtn9 = document.getElementById("closeModalBtn9");
const modal9 = document.getElementById("myModal9");

openModalBtn9.addEventListener("click", () => {
    modal9.style.display = "block";
});

closeModalBtn9.addEventListener("click", () => {
    modal9.style.display = "none";
});

window.addEventListener("click", (event) => {
    if (event.target == modal9) {
        modal9.style.display = "none";
    }
});